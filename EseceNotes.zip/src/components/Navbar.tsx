"use client";

import { signIn, signOut, useSession } from "next-auth/react";
import Link from "next/link";
import Image from "next/image";
import { useState } from "react";
import { LogOutIcon, MenuIcon, SettingsIcon, XIcon } from "lucide-react";

export default function Navbar() {
    const { data: session } = useSession();
    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const [isDropdownOpen, setIsDropdownOpen] = useState(false);

    if (!session) {
        return null;
    }

    return (
        <nav className="bg-neutral-900 text-white border-neutral-700 h-20">
            <div className="max-w-screen-xl flex flex-wrap items-center justify-between mx-auto p-5">
                {/* Logo y nombre */}
                <Link href="/" className="flex items-center">
                    <Image
                        src="/logofinal.webp"
                        alt="Logo de la aplicación"
                        width={100}
                        height={100}
                        className="rounded-full"
                        quality={100}
                    />
                </Link>

                {/* Sección de usuario y menú móvil */}
                <div className="flex items-center md:order-2 space-x-3 md:space-x-0 rtl:space-x-reverse">
                    {/* Botón/Perfil de usuario */}
                    {session?.user && (
                        <div className="relative">
                            <button
                                type="button"
                                onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                                className="flex text-sm bg-neutral-800 rounded-full cursor-pointer border border-transparent hover:border-neutral-400 focus:border-neutral-400 transition duration-200"
                                aria-expanded={isDropdownOpen}
                            >
                                <Image
                                    src={session.user.image || ''}
                                    alt="Foto del usuario"
                                    width={40}
                                    height={40}
                                    className="rounded-full size-10"
                                    quality={100}
                                />
                            </button>
                            {/* Dropdown del usuario */}
                            {isDropdownOpen && (
                                <div className="absolute right-0 mt-6 z-50 text-base list-none bg-neutral-900 border-neutral-700 divide-y divide-neutral-700 rounded-xl shadow-lg">
                                    <div className="px-4 py-3">
                                        <span className="block text-sm text-white font-bold">
                                            {session.user.name}
                                        </span>
                                        <span className="block text-sm text-neutral-400 truncate">
                                            {session.user.email}
                                        </span>
                                    </div>
                                    <ul className="py-2">
                                        <li>
                                            <Link
                                                href="/settings"
                                                className="w-full flex items-center justify-between gap-1 px-4 py-2 text-sm text-white hover:bg-neutral-700 cursor-pointer"
                                                onClick={() => setIsDropdownOpen(false)}
                                            >
                                                Configuración
                                                <SettingsIcon className="size-4" />
                                            </Link>
                                        </li>
                                        <li>
                                            <button
                                                onClick={() => {
                                                    setIsDropdownOpen(false);
                                                    signOut({ callbackUrl: '/' });
                                                }}
                                                className="w-full flex items-center justify-between gap-1 px-4 py-2 text-sm text-white hover:bg-neutral-700 cursor-pointer"
                                            >
                                                Cerrar Sesión
                                                <LogOutIcon className="size-4" />
                                            </button>
                                        </li>
                                    </ul>
                                </div>
                            )}
                        </div>
                    )}

                    {/* Botón de hamburguesa para móvil */}
                    <button
                        onClick={() => setIsMenuOpen(!isMenuOpen)}
                        type="button"
                        className="inline-flex items-center p-2 w-10 h-10 justify-center text-sm text-neutral-400 rounded-xl md:hidden hover:bg-neutral-700 transition duration-200 border border-transparent focus:border-neutral-400 ml-2"
                        aria-controls="navbar-menu"
                        aria-expanded={isMenuOpen}
                    >
                        {!isMenuOpen ? (
                            <MenuIcon />
                        ) : (
                            <XIcon className="animate-pulse" />
                        )}
                    </button>
                </div>

                {/* Menú de navegación */}
                <div
                    className={`${isMenuOpen ? 'block' : 'hidden'
                        } items-center justify-between w-full md:flex md:w-auto md:order-1 z-40`}
                    id="navbar-menu"
                >
                    <ul className="flex flex-col font-medium py-2 md:p-0 mt-6 border border-neutral-700 rounded-xl bg-neutral-900 md:space-x-8 rtl:space-x-reverse md:flex-row md:mt-0 md:border-0 md:bg-transparent">
                        <li>
                            <Link
                                href="/inicio"
                                className={`${isMenuOpen ? 'flex items-center justify-between' : 'block'
                                    } py-2 px-6 text-white hover:bg-neutral-700 md:hover:bg-transparent md:hover:text-neutral-400 md:p-0 transition duration-200`}
                                aria-current="page"
                                onClick={() => setIsMenuOpen(false)}
                            >
                                Inicio
                                {isMenuOpen ? (
                                    <LogOutIcon className="size-4" />
                                ) : null}
                            </Link>
                        </li>
                        <li>
                            <Link
                                href="/"
                                className={`${isMenuOpen ? 'flex items-center justify-between' : 'block'
                                    } py-2 px-6 text-white hover:bg-neutral-700 md:hover:bg-transparent md:hover:text-neutral-400 md:p-0 transition duration-200`}
                                aria-current="page"
                                onClick={() => setIsMenuOpen(false)}
                            >
                                Sobre mí
                                {isMenuOpen ? (
                                    <LogOutIcon className="size-4" />
                                ) : null}
                            </Link>
                        </li>
                        <li>
                            <Link
                                href="/inicio"
                                className={`${isMenuOpen ? 'flex items-center justify-between' : 'block'
                                    } py-2 px-6 text-white hover:bg-neutral-700 md:hover:bg-transparent md:hover:text-neutral-400 md:p-0 transition duration-200`}
                                aria-current="page"
                                onClick={() => setIsMenuOpen(false)}
                            >
                                Servicios
                                {isMenuOpen ? (
                                    <LogOutIcon className="size-4" />
                                ) : null}
                            </Link>
                        </li>
                        <li>
                            <Link
                                href="/inicio"
                                className={`${isMenuOpen ? 'flex items-center justify-between' : 'block'
                                    } py-2 px-6 text-white hover:bg-neutral-700 md:hover:bg-transparent md:hover:text-neutral-400 md:p-0 transition duration-200`}
                                aria-current="page"
                                onClick={() => setIsMenuOpen(false)}
                            >
                                Contacto
                                {isMenuOpen ? (
                                    <LogOutIcon className="size-4" />
                                ) : null}
                            </Link>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    );
}
