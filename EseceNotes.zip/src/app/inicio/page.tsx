export default function InicioPage() {
    return (
        <>
            <h1>Hola mundo, este es el Inicio Page.</h1>
        </>
    )
}
