export default function HomePage() {
    return (
        <main>
            <h1>Hola mundo, este es el / Page.</h1>
        </main>
    );
}
